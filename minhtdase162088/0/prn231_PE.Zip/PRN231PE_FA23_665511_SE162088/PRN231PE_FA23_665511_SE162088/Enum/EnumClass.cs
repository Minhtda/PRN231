﻿namespace ControllerAPI.Enum
{
    public static class EnumClass
    {
        public static class RoleNames
        {
            public const string Admin = "1";
            public const string Staff = "2";
            public const string Manager = "3";
            public const string Member = "4";
        }
    }
}
