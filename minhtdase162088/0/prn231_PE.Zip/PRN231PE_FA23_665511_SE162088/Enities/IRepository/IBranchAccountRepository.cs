﻿using Enities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enities.IRepository
{
    public interface IBranchAccountRepository : IGenericRepository<BranchAccount>
    {
    }
}
