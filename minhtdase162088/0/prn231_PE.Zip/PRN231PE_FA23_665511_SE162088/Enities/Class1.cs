﻿namespace Enities
{
    public class Class1
    {

    }
}