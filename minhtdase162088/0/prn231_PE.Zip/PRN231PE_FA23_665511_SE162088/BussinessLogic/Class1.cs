﻿namespace BussinessLogic
{
    public class Class1
    {

    }
}